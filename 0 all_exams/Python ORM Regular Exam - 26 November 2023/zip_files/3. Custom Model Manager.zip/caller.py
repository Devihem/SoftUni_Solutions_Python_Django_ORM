import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from main_app.models import Author, Article, Review
from django.db.models import Count


# Import your models here
# Create and run your queries within functions

# def get_authors_by_article_count():
#     pass
#     return Author.objects.annotate(art_count=Count('article')).order_by('-art_count', 'email')
#
#
# for x in get_authors_by_article_count():
#     print(x.__dict__)
