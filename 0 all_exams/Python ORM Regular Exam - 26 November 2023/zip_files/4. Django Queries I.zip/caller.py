import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from main_app.models import Author, Article, Review
from django.db.models import Count, Q, F


# Import your models here
# Create and run your queries within functions

def get_authors(search_name=None, search_email=None):
    query_run = []
    print_log = []

    if search_name:
        query_run.append(Q(full_name__icontains=search_name))

    if search_email:
        query_run.append(Q(email__icontains=search_email))

    if search_name or search_email:
        authors_selected = Author.objects.filter(*query_run).order_by('-full_name')

        for author in authors_selected:
            print_log.append(
                f"Author: {author.full_name}, email: {author.email}, status: {'Banned' if (author.is_banned) else 'Not Banned'}"
            )

    return '\n'.join(print_log)


def get_top_publisher():
    print_log = ""
    top_publisher = Author.objects.get_authors_by_article_count().first()

    if top_publisher:
        if top_publisher.art_count > 0:
            print_log = f"Top Author: {top_publisher.full_name} with {top_publisher.art_count} published articles."

    return print_log


def get_top_reviewer():
    print_log = ''
    top_rev_auth = Author.objects.annotate(rev_count=Count("review")).order_by('-rev_count', 'email').first()

    if top_rev_auth:
        if top_rev_auth.rev_count > 0:
            print_log = f"Top Reviewer: {top_rev_auth.full_name} with {top_rev_auth.rev_count} published reviews."

    return print_log


