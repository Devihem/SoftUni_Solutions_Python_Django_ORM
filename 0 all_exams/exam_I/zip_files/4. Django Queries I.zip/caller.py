import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from main_app.models import Director, Movie, Actor
from django.db.models import Count, Q, Avg


# Import your models here
# Create and run your queries within functions


def get_directors(search_name=None, search_nationality=None):
    query_run = []

    if search_name:
        query_run.append(Q(full_name__icontains=search_name))

    if search_nationality:
        query_run.append(Q(nationality__icontains=search_nationality))

    print_log = []
    if search_name or search_nationality:

        directors_query = Director.objects.all().filter(*query_run).order_by('full_name')
        print_log = []
        for director in directors_query:
            print_log.append(
                f"Director: {director.full_name}, nationality: {director.nationality}, experience: {director.years_of_experience}")

    return '\n'.join(print_log)


def get_top_director():
    top_director = Director.objects.get_directors_by_movies_count().first()
    print_log = []
    if top_director:
        print_log.append(f"Top Director: {top_director.full_name}, movies: {top_director.movies_count}.")

    return ''.join(print_log)


def get_top_actor():
    top_actor = Actor.objects.annotate(m_count=Count('starring_actors')).order_by('-m_count', 'full_name').first()

    if top_actor:
        movies_list = Movie.objects.filter(starring_actor=top_actor)

        if movies_list:
            movie_titles = ', '.join([movie.title for movie in movies_list])
            movie_avg_rating = round(sum([movie.rating for movie in movies_list]) / len(movies_list), 1)

            return f"Top Actor: {top_actor.full_name}, starring in movies: {movie_titles}, movies average rating: {movie_avg_rating}"
        
    return ""

