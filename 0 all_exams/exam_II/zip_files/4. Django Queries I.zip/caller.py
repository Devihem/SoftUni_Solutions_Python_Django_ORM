import os
import django
from django.db.models import Count, Q

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
# Create and run your queries within functions


import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from _decimal import Decimal
from datetime import datetime, timedelta
from main_app.models import Product, Order, Profile


def get_profiles(search_string=None):
    result_print_log = []

    if isinstance(search_string, str):
        result_print_log = []
        profiles_selected = Profile.objects.filter(
            Q(full_name__icontains=search_string) |
            Q(email__icontains=search_string) |
            Q(phone_number__icontains=search_string)

        ).annotate(orders_count=Count('order')).order_by('full_name')

        for profile in profiles_selected:
            result_print_log.append(
                f"Profile: {profile.full_name}, email: {profile.email}, phone number: {profile.phone_number}, orders: {profile.orders_count}")

        return '\n'.join(result_print_log)
    return ""


def get_loyal_profiles():
    result_print_log = []
    profiles_selected = Profile.objects.get_regular_customers()

    if profiles_selected:
        for profile in profiles_selected:
            result_print_log.append(
                f"Profile: {profile.full_name}, orders: {profile.orders_count}"
            )

    return '\n'.join(result_print_log)


def get_last_sold_products():
    result_print_log = []
    last_order = Order.objects.last()

    if last_order:
        product_list = [product.name for product in last_order.products.all().order_by('name')]
        result_print_log.append(
            f"Last sold products: {', '.join(product_list)}")

        return result_print_log[0]
    return ""

print(get_last_sold_products())