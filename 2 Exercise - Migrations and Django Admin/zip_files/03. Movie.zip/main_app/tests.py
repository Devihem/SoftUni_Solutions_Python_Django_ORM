from django.test import TestCase

# Create your tests here.
x ="''titanik;;''"
z = " ''asdas''dasd"
print(f'Movie "{x}" by "{z}"')