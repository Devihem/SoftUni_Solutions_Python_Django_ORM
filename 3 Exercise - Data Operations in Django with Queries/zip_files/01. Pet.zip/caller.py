import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Pet


# Create queries within functions
def create_pet(pet_name: str, pet_species: str):
    pet = Pet(
        name=pet_name,
        species=pet_species
    )
    pet.save()

    return f"{pet_name} is a very cute {pet_species}!"

#
# print(create_pet('Buddy', 'Dog'))
# print(create_pet('Whiskers', 'Cat'))
# print(create_pet('Rocky', 'Hamster'))
