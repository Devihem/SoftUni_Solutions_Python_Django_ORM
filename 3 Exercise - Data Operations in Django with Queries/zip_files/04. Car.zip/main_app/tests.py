from django.test import TestCase

# Create your tests here.

x = 100
print( sum(list(str(x))))