import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Author, Book


# Create queries within functions

# 01. Library
def show_all_authors_with_their_books():
    print_log_list = []

    for author in Author.objects.all().order_by('id'):
        author_name = author.name
        author_books = [str(book) for book in author.book_set.all()]
        if not author_books:
            continue
        print_log_list.append(
            f"{author_name} has written - {', '.join(author_books)}!")

    return '\n'.join(print_log_list)


def delete_all_authors_without_books():

    for author in Author.objects.all():
        if not author.book_set.all():
            author.delete()

# Create authors
# author1 = Author.objects.create(name="J.K. Rowling")
# author2 = Author.objects.create(name="George Orwell")
# author3 = Author.objects.create(name="Harper Lee")
# author4 = Author.objects.create(name="Mark Twain")
#
# # Create books associated with the authors
# book1 = Book.objects.create(
#     title="Harry Potter and the Philosopher's Stone",
#     price=19.99,
#     author=author1
# )
# book2 = Book.objects.create(
#     title="1984",
#     price=14.99,
#     author=author2
# )
#
# book3 = Book.objects.create(
#     title="To Kill a Mockingbird",
#     price=12.99,
#     author=author3
# )


# print(show_all_authors_with_their_books())
# # Delete authors without books
# delete_all_authors_without_books()
# print(Author.objects.count())