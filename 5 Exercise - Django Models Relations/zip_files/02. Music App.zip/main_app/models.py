from django.db import models


# Create your models here.


# 01. Library

class Author(models.Model):
    name = models.CharField(max_length=40)

    def __str__(self):
        return self.name


class Book(models.Model):
    title = models.CharField(max_length=40)
    price = models.DecimalField(max_digits=5, decimal_places=2)
    author = models.ForeignKey(to=Author, on_delete=models.CASCADE)

    def __str__(self):
        return self.title


# 02. Music App

class Song(models.Model):
    title = models.CharField(max_length=100)


class Artist(models.Model):
    name = models.CharField(max_length=100)
    songs = models.ManyToManyField(to=Song, related_name='artists')

# 03. Shop
# 04. License
# 05. Car Registration
# 06. Car Admin Setup
