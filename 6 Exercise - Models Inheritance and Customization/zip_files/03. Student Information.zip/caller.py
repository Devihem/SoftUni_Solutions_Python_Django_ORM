import os
import django



# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()
#
# from main_app.models import Student
# # Test cases
# student1 = Student(name="John", student_id=12345)
# student1.save()
#
# student2 = Student(name="Alice", student_id=45.23)
# student2.save()
#
# student3 = Student(name="Bob", student_id="789")
# student3.save()
#
# # Retrieving student IDs from the database
# retrieved_student1 = Student.objects.get(name="John")
# retrieved_student2 = Student.objects.get(name="Alice")
# retrieved_student3 = Student.objects.get(name="Bob")
#
# print(retrieved_student1.student_id)