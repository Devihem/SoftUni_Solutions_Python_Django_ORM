from django.db import models


# Create your models here.

# 01. Zoo Animals
class Animal(models.Model):
    name = models.CharField(max_length=100)
    species = models.CharField(max_length=100)
    birth_date = models.DateField()
    sound = models.CharField(max_length=100)


class Mammal(Animal):
    fur_color = models.CharField(max_length=50)


class Bird(Animal):
    wing_span = models.DecimalField(max_digits=5, decimal_places=2)


class Reptile(Animal):
    scale_type = models.CharField(max_length=50)

# 02. Zoo Employees
# 03. Animal Display System
# 04. Zookeeper's Specialty
# 05. Animal Display System Logic
# 06. Animal's Age
# 07. Veterinarian Availability
