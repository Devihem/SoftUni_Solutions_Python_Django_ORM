import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()
from django.core.exceptions import ValidationError
from main_app.models import VideoGame, Invoice, BillingInfo, Technology, Project, Programmer
from django.db.models import Sum, Count
#
# # Create instances of Technology
# tech1 = Technology.objects.get(name="Python", description="A high-level programming language")
# tech2 = Technology.objects.get(name="JavaScript", description="A scripting language for the web")
# tech3 = Technology.objects.get(name="SQL", description="Structured Query Language")
#
# # Create instances of Project
# project1 = Project.objects.get(name="Web App Project", description="Developing a web application")
#
#
# project2 = Project.objects.get(name="Database Project", description="Managing databases")
#
# # Create instances of Programmer
# programmer1 = Programmer.objects.get(name="Alice")
# programmer2 = Programmer.objects.get(name="Bob")

# Associate projects with programmers

# # Execute the "get_programmers_with_technologies" method for a specific project
specific_project = Project.objects.get(name="Web App Project")

programmers_with_technologies = specific_project.get_programmers_with_technologies()
#
# Iterate through the related programmers and technologies
# for programmer in programmers_with_technologies:
#     print(f"Programmer: {programmer.name}")
#     for technology in programmer.projects.get(name="Web App Project").technologies_used.all():
#         print(f"- Technology: {technology.name}")
#
# Execute the "get_projects_with_technologies" method for a specific programmer
# specific_programmer = Programmer.objects.get(name="Alice")
# projects_with_technologies = specific_programmer.get_projects_with_technologies()
#
# # Iterate through the related projects and technologies
# for project in projects_with_technologies:
#     print(f"Project: {project.name} for {specific_programmer.name}")
#     for technology in project.technologies_used.all():
#         print(f"- Technology: {technology.name}")